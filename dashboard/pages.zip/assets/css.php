<link rel="shortcut icon" href="assets/pmi-bg.png" type="image/x-icon">
<link rel="shortcut icon" href="assets/pmi-bg.png" type="image/png">
<link rel="stylesheet" href="../assets/compiled/css/app.css">
<link rel="stylesheet" href="../assets/compiled/css/app-dark.css">
<link rel="stylesheet" href="../assets/compiled/css/auth.css">